/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <unordered_map>
using namespace std;

int main() {
    unordered_map<string, int> marks;

    
    marks["Ravi"] = 85;
    marks["Aman"] = 90;
    marks["Neha"] = 78;

    cout << "Student Marks:" << endl;

    for (auto it : marks) {
        cout << it.first << " : " << it.second << endl;
    }

    return 0;
}
