/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <queue>
using namespace std;

int main() {
    queue<int> q;

    
    q.push(10);
    q.push(20);
    q.push(30);

    
    q.pop();

    cout << "Queue elements:" << endl;

    while (!q.empty()) {
        cout << q.front() << endl;
        q.pop();
    }

    return 0;
}
